<?php
function opn($array)
{
    echo '<pre>';
    print_r($array);
}
?>