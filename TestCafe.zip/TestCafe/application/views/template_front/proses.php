<div class="pizzaro-order-steps">
    <ul>
        <li class="cart">
            <span class="step">1</span>Order Cart
        </li>
        <li class="checkout">
            <span class="step">2</span>Konfirmasi
        </li>
        <li class="complete">
            <span class="step">3</span>Order Selesai
        </li>
    </ul>
</div>